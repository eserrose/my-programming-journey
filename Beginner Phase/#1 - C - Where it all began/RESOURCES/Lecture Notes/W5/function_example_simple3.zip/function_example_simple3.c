#include <stdio.h>
#include <stdlib.h>

int topla(int x,int y)
    {
//	int sonuc=x+y;
	return x+y;
	}
	
int carp(int x,int y)
    {	
//	int sonuc=x*y;
	return x*y;
	}
int kare(int x,int y)
    {
//	int sonuc=topla(x,y);
	return carp(topla(x,y),topla(x,y));
	}
	
int usal(int x,int y)
    {
	int i;
	int sonuc=1;
//	for(int i=1;i<=y;i++)
	for(i=1;i<=y;i++)	
	{		
	sonuc*=x;	
	}
	return sonuc;
	}
	
int fak(int x)
    {
    int i;
	int sonuc=1;
	for(i=1;i<=x;i++)
	{
		sonuc*=i;
	}
	return sonuc;	
    }
int main()
{
	int a,b;
	printf("2 sayi gir :\n");
	scanf("%d%d",&a,&b);	
	printf("Toplam :%d\n",topla(a,b));
	printf("Carpim :%d\n",carp(a,b));
	printf("TOplamlarinin Karesi :%d\n",kare(a,b));
	
	printf("Us ve taban sayi gir :\n");
	scanf("%d%d",&a,&b);
	printf("%d ussu %d  :%d\n",a,b,usal(a,b));
	
	printf("1 sayi gir :\n");
	scanf("%d",&a);
	printf("%d faktoriyel :%d\n",a,fak(a));	
}
